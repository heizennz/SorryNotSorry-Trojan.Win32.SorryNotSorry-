# SorryNotSorry (Trojan.Win32.SorryNotSorry!)
This is my Horror trojan called SorryNotSorry!.exe and it is a trojan with flashy stuff
and i hope you enjoy this malware if you test or review it.

- Heizenn

# Some fun facts about this trojan
1. This horror trojan was made in 1 or 2 weeks
2. it oddly looks like Clutt6.6.6

# Features
1. MBR corruption
2. File encryption via AES
3. Different payloads for supported and unsupported OS versions
4. GDI

# Compatibility
Windows 11
Windows 10 (OS tested on)
Older Windows Version that isnt Vista or older

# Pictures
* <b>GDI:</b> Preview of Unusable Stage
<p align="center"><img src="Images/Preview.png"></p>

* <b>MBR:</b> MBR on compatible OS
<p align="center"><img src="Images/MBR.png"></p>

* <b>MBR:</b> MBR on incompatible OS
<p align="center"><img src="Images/MBR2.png"></p>

# Credits

@Heizenn - Creator of Malware
